# Projet_interconnexion
Voici mes apports que j'ai effectués 

Concrètement ce qui fonctionne :

-ospf
-dhcp
-le vpn
-DNS
-filtrage pv/public 

Ce qu'il faut terminer :

-WEB
-FTP (cf léo)
-DMZ
-VOIP (cf Guillaume)

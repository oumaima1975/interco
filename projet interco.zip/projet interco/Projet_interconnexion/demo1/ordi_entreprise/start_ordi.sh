apt-get install -y iptables iproute2
ip route add 120.0.20.0/24 via 192.168.2.71
sleep infinity
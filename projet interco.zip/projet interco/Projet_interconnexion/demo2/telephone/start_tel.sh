apt-get install -y isc-dhcp-client 
dhclient -r eth0
dhclient eth0
sleep infinity